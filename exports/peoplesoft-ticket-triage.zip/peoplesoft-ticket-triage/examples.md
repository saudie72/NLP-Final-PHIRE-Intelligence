# Worked examples (synthetic)

## 1. Comp time paid as overtime

*Ticket:* "A Public Works hourly employee (workgroup PW_HOURLY) earned 95 hours of comp time this year, but 15 were
paid as overtime instead of banked."

| Field | Value | Cue |
|---|---|---|
| Module | TL | comp time, workgroup, timesheet |
| Issue area | Functional | wrong-looking amount, no error |
| Priority | M | one employee, no deadline |

Working as designed: PW_HOURLY caps the comp bank at 80 hours in `PW_RULES`; 95 - 80 = 15 hours paid as `OT15`
(tl-trc-setup-synthetic.md, Quirk B).

## 2. Process stuck in Queued

*Ticket:* "Time Administration submitted Sunday night is still Queued; approvers in two departments can't see
payable time; pay confirmation is Thursday."

| Field | Value | Cue |
|---|---|---|
| Module | TL | Time Administration, payable time |
| Issue area | Administration | Queued, never started |
| Priority | H | payroll deadline, two departments |

Hypotheses: Process Scheduler server down or not polling; blocking process in the queue.

## 3. New report request

*Ticket:* "Finance requests a new report of garnishment deductions by pay period and Deduction Code."

| Field | Value | Cue |
|---|---|---|
| Module | PY | garnishment, deduction, pay period |
| Issue area | Technical | new report |
| Priority | M | no payroll risk or deadline |
